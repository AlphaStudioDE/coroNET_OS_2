
$fn=48;
leaf_colors=["Orange","Gold","Tomato","SandyBrown","Khaki","Goldenrod","Coral"];
module fabric(z=0) {
    color([.26,.29,.32]) translate([0,0,z-1.2])
    linear_extrude(1.2) difference() {
        square([220,210],center=true); square([100,100],center=true);
    }
}
module fan(w,d,pitch) {
    color([.25,.14,.09]) linear_extrude(d) difference() {
        offset(r=3) square([w-6,w-6],center=true);
        circle(d=w-7);
        for(x=[-pitch/2,pitch/2],y=[-pitch/2,pitch/2]) translate([x,y]) circle(d=4);
    }
    color([.58,.40,.26]) translate([0,0,d*.52]) {
        cylinder(d=w*.34,h=d*.24);
        for(a=[0:360/7:359]) rotate([0,0,a]) translate([w*.15,0,1.5])
            linear_extrude(1.3) scale([w/80,w/80])
                polygon([[0,-3],[20,-8],[24,0],[4,7]]);
    }
}
module servo() {
    color([.19,.38,.68]) translate([-16.4,-6.1,0]) cube([22.8,12.2,16]);
    color([.24,.48,.80]) translate([-22,-4,0]) cube([33,8,2]);
    color("Silver") translate([0,0,-6]) cylinder(d=5.4,h=6);
}
module nuts(xy,z) {
    color("Silver") for(x=[-xy,xy],y=[-xy,xy])
        translate([x,y,z]) cylinder(d=6.3,h=2.4,$fn=6);
}

opening=0.72;
cutaway=false;
show_adapter=true;
zlist=[4.7, 5.95, 7.2, 8.45, 9.7, 10.95, 12.2];
P=[24.0, 0.0]; S=[37.335238046649714, 37.335238046649714];
fabric();
color("Gainsboro") translate([0,0,-6.2]) import("STL/06_ramka_wewnetrzna_1szt.stl");
nuts(45,-8.6);
color("SlateGray") import("STL/01_taca_z_kolnierzem_1szt.stl");
for(i=[0:6]) color(leaf_colors[i]) rotate([0,0,360*i/7])
    translate([P[0],P[1],zlist[i]]) rotate([0,0,-60*opening])
    translate([-P[0],-P[1],0]) import("STL/03_listek_7szt.stl");
color("Goldenrod") translate([0,0,15.5]) rotate([0,0,-20*opening]) import("STL/04_pierscien_1szt.stl");
color("Khaki") translate([S[0],S[1],15.5])
    rotate([0,0,225+(108/24)*(45+20*opening)-180/24])
    translate([0,0,3.5]) rotate([180,0,0]) import("STL/05_zebatka_1szt.stl");
if(!cutaway) {
    color("LightSteelBlue",.85) translate([0,0,27]) rotate([180,0,0]) import("STL/02_pokrywa_z_mocowaniem_serwa_1szt.stl");
    translate([0,0,24]) fan(40,20,32);
    translate([S[0],S[1],27]) rotate([0,0,135]) servo();
    if(show_adapter) color("SeaGreen") translate([0,0,44])
        translate([0,0,35.8]) rotate([180,0,0]) import("STL/08_wyjscie_M1_1szt.stl");
}
