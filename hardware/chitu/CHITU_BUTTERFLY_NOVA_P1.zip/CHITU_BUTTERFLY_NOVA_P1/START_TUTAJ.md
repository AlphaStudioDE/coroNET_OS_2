# Chitu: klapa motylkowa P1

Osobny, eksperymentalny projekt. Nie mieszać części z paczkami irisa.
Do jednej drukarki użyj **jednego** podfolderu: `NF_40mm` albo `NF_80mm`.

| Wariant | Wentylator | Przelot korpusu | Kołnierz / ramka | Wystaje na zewnątrz z wentylatorem* |
| --- | --- | ---: | --- | ---: |
| 40 mm | Noctua NF-A4x20 PWM (12 V) | Ø38 mm | 130 / 130 mm | 70 mm |
| 80 mm | Noctua NF-A8 5V PWM (27 mm z poduszkami) | Ø76 mm | 140 / 130 mm | 115 mm |

*Bez łbów, przewodów i ewentualnej osłony. Kołnierze są kwadratowe. Serwo
80 mm może wystawać poza obrys 140 mm, jeżeli wymaga dystansów.
Zespół jest po stronie zewnętrznej, wewnątrz pokrywy zostaje tylna ramka.

## Najpierw próba

1. Zmierz światło otworu między szwami i sprawdź także narożniki, zakładkę
   pod ramkę i dostępną przestrzeń z każdej strony. Założenie to otwór
   100 × 100 mm i tkanina 1,35 mm przed ściśnięciem, nie tolerancja producenta.
2. Wydrukuj tylko sprawdzian 95,4 mm oraz próbki czopa Ø6,4 mm i otworu
   Ø7,1 mm. Sprawdź, czy czop obraca się po usunięciu gratu. Sprzęgło D możesz
   wydrukować osobno i przymierzyć do próbki klucza D.
3. Sprawdź faktyczny MG90S: rozstaw mocowania 27,8 mm, położenie wału
   względem uszu i miejsce na orczyk. Projekt zakłada odległość **7,55 mm**
   od płaszczyzny uszu do spodniej powierzchni orczyka stykającej się ze
   sprzęgłem (bez liczenia samej grubości orczyka). Jeśli potrzebna odległość
   jest większa, zastosuj dwa równe dystanse i odpowiednio dłuższe śruby M2.
   W `PROBKI` są dystanse 1, 2, 4 i 8 mm. Nie ściskaj mechanizmu osiowo
   śrubami. Jeżeli odległość jest mniejsza lub oś się nie pokrywa,
   nie montuj na siłę: potrzebna jest korekta uchwytu lub sprzęgła.

## Druk i mocowanie

- `STL`: 6 typów, 9 wydruków. Liczby sztuk podaje `LISTA_DRUKU.csv`.
- `PROBKI`: nie drukuj wszystkiego do montażu. Ograniczniki robocze
  1,2 mm są w `STL`. Wersję 1,0 mm stosuj wyłącznie, jeśli 1,2 mm
  nie zapewnia chwytu. Nie mieszaj grubości i nie dociskaj po oparciu o stopery.
- Start: dysza 0,4 mm, warstwa 0,16–0,20 mm, korpusy 4–5 obrysów, klapa
  i sprzęgło z gęstym wypełnieniem. Sprawdź podpory pod czopami drukowanymi
  poziomo, półpanewkami i uszami skręcania. Usuń podpory tak, żeby nie
  uszkodzić powierzchni pracujących. Materiał dobierz do temperatury i obciążenia;
  żaden wydruk nie ma potwierdzonej wytrzymałości w gorącej komorze.
- Zacisk: 4 śruby M3 × 12, podkładki od strony zewnętrznej i nakrętki
  w środku. Montaż na istniejącym otworze, bez dziurawienia tkaniny.
  Zmierz dostępny gwint i sprawdź, czy końce śrub niczego wewnątrz nie zaczepiają.
- Podział korpusu: 4 śruby M3 × 10 i nakrętki M3. Nakrętki wkłada się
  od spodu w gniazda dolnej części przed połączeniem połówek. Dokręć od
  zewnątrz przez cztery otwory dostępu w płycie wentylatora, przed jego założeniem.
- Wentylator: 4 śruby M3 z płaską powierzchnią oporową, podkładki i nakrętki.
  Punkt startowy to M3 × 30 dla 40 mm lub M3 × 35 dla 80 mm z poduszkami;
  dobierz długość do faktycznej grubości obudowy i podkładek. Końce śrub
  nie mogą wejść w wirnik ani drogę klapy.
- Uchwyt serwa ma dwa piloty Ø1,6 mm pod M2. Użyj fabrycznego orczyka
  i jego śruby centralnej. Sprzęgło ma dwa otwory Ø1,7 mm na rozstawie 10 mm;
  dobierz lub przewierć orczyk i użyj krótkich śrub, które nie wyjdą w stronę
  klapy. Zostaw dostęp do śruby centralnej. Najpierw przymierz na stole.

## Montaż i próba ruchu

1. Włóż klapę czopami w dolną połowę; klucz D ma być od strony uchwytu serwa.
   Zamknij drugą połową korpusu i skręć równomiernie. Sprawdź ręką pełny zakres
   od zamknięcia do około 90° i lekki luz osiowy. Nic nie może haczyć.
2. Zespół zacisku sprawdź osobno, bez obciążenia, a pierwszą próbę z ciężarem
   wykonaj z podparciem. Nie przenoś ciężaru przewodu wyciągowego na tkaninę,
   szczególnie w dłuższej wersji 80 mm.
3. Osadź sprzęgło na kluczu D i sprawdź, czy po przymiarce na orczyku pozostaje
   wsunięte na kilka milimetrów, bez dociskania czopów do obudowy. Załóż
   serwo z wyłączonym napędem dopiero po próbie ręcznej.
4. Z odpiętym orczykiem ustal zakres i pozycję rozruchową MG90S w coroNET.
   Dopiero po tym zamontuj orczyk, zaczynaj od małych ruchów i zwiększaj zakres
   stopniowo. Nie podawaj od razu pełnego 0–180°. Otwarta oznacza klapę
   równoległą do przepływu; dalszy obrót zaczyna ponownie ją przymykać.
5. Przed zasileniem zamontuj osłonę, jeśli można dotknąć wirnika lub klapy.
   Sprawdź kierunek wyciągu, prowadzenie kabli i przepływ z faktycznym
   filtrem lub kanałem. Przetestuj trzymanie zacisku w temperaturze pracy.

## Co wykazała kontrola cyfrowa

Próbkowanie co 1° od 0 do 90°: bez wykrytej kolizji klapy i sprzęgła
z obiema połówkami oraz klapy ze sprzęgłem. Sprawdzono także obwiednię
wentylatora, otwory zacisku i dostęp narzędzia do śrub podziału przed
montażem wentylatora. Szczegóły w `WALIDACJA.json`. Podgląd złożenia w
`PODGLAD.scad` służy tylko do obejrzenia mechanizmu (kąt 0° lub 90°).

Nominalne wolne pole przekroju przy otwarciu to ok. **79% (40 mm)**
lub **89% (80 mm)**. Przy zamknięciu obwodowa szczelina daje geometrycznie
ok. **6,7% / 3,4%** wolnego pola. Te liczby dotyczą geometrii, **nie**
mierzonego przepływu, szczelności, bezpieczeństwa oparów ani wydajności filtra.
To nie jest zawór szczelny. Nie wykonano testu fizycznego.
