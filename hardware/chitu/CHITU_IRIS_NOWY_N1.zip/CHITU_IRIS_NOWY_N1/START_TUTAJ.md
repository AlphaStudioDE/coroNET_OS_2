# Chitu Iris N1: nowe zespoly 40 i 80 mm

Niezalezne prototypy do otworu 100 x 100 mm i tkaniny 1,35 mm.
Nie lacz ich czesci z poprzednimi irisami. Wentylator, MG90S i caly
mechanizm sa **na zewnatrz**. W srodku jest ramka 130 x 130 x 5 mm
plus nakretki i ewentualny naddatek srub. Zostaw bezpieczny luz dla
glowicy, przewodow i ugiecia tkaniny. Nie dziuraw tkaniny.

| Folder | Wentylator | Przelot irisa | Zewnetrzny kolnierz | Wystawanie z baza M1* |
| --- | --- | ---: | ---: | ---: |
| NF_40mm | NF-A4x20 PWM, 12 V | 38 mm | 130 x 130 mm | 79,8 mm |
| NF_80mm | NF-A8 5V PWM, do 27 mm z poduszkami | 76 mm | 140 x 140 mm | 55 mm |

*Od zewnetrznej powierzchni tkaniny, bez uszczelek, lbow, przewodow,
filtra i rury. Bez bazy M1: nominalnie 44 / 51 mm (korpus i wentylator).
Mala baza M1 jest dluzsza, bo rozszerza wylot 40 mm do wspolnego formatu.

## Co drukowac

Wybierz jeden rozmiar. Osiem typow STL daje lacznie 17 sztuk:
taca 1, pokrywa 1, listek 7, pierscien 1, zebatka 1, ramka wewnetrzna 1,
ogranicznik 4, baza M1 1. Sprawdzian otworu nie jest czescia montazowa.
Wydrukuj go pierwszy. Nie wciskaj w tkanine ani nie zmieniaj skali STL.
Druk probny: dysza 0,4 mm, warstwa ok. 0,16–0,20 mm, bez podpory
w szczelinach i otworach roboczych. W slicerze sprawdz podpory pod
pokrywa, polkami tacy i dluga przejsciowka 40 mm. Nie prostuj listkow
napedem. Uzyj materialu dobranego do rzeczywistej temperatury i obciazenia.

## Elementy montazowe i proba na stole

1. Sprawdz otwor 95,4 mm, miejsce na boczny wentylator i swobodny tor
   glowicy. Zacisk ma cztery M3 na rozstawie 90 mm. Od zewnatrz wloz
   cztery **M3 z plaskim lbem stozkowym 90 stopni** (leb do ok. 6 mm),
   nominalnie M3 x 12; dobierz dlugosc do nakretek. Lby musza byc na
   rowno z podloga tacy, inaczej moga zahaczyc o mechanizm. Zaloz
   cztery stopery 1,2 mm i ramke od srodka. Dociskaj na krzyz bez
   wymuszania zgniatania. Zweryfikuj przyczepnosc pod obciazeniem osobno.
2. Uzyj 7 metalowych osi i 7 metalowych zabierakow, nominalnie **3 mm**.
   Prowadnice w druku maja nominalna srednice 2,96 mm pod dopasowanie;
   skalibruj otwory na probce. Trzpienie maja byc zabezpieczone przed
   wypadnieciem, proste, wygladzone i bez wyplywek kleju. Nie uzywaj
   luznych trzpieni ani gwintu jako powierzchni slizgowej.
3. Osie statyczne: nominalnie ok. 14 mm dlugosci, po osadzeniu koniec
   na ok. 14 mm od spodu tacy (ponizej pierscienia). Od osi na +X
   przechodz przeciwnie do ruchu wskazowek zegara, patrzac z zewnatrz.
   Dolny listek jest na pierwszym stanowisku. Na kazdym nastepnym
   poziom rosnie o 1,25 mm. Wkladaj identyczne listki po kolei.
4. Zabieraki montuje sie do pierscienia. Projekcja **pod spod pierscienia**
   od najnizszego listka: 10,70 / 9,45 / 8,20 / 6,95 / 5,70 / 4,45 /
   3,20 mm. Do kazdego dodaj ok. 2,5 mm osadzenia w pierscieniu.
   Nie pomyl projekcji z dlugoscia ciecia. Trzpienie nie moga wystawac
   powyzej gory pierscienia ani opierac sie o listki lub tace. Zaloz
   pierscien i sprawdz recznie cale 20 stopni jego skoku.
5. MG90S z fabrycznym orczykiem montuje sie **walem w dol**. Uchwyt 27,8 mm,
   otwory pod M2. Zalezne od klona: wysokosc osiowa orczyka, glebokosc
   gwintu i wystawanie lbow. Zebatka ma kieszen na przyciety orczyk
   (13,6 x 4,5 mm, glebokosc 1,5 mm) i dwa otwory o rozstawie 9 mm.
   Nie drukuj wieloklinu. Mocuj fabryczna sruba centralna oraz dwiema
   krotkimi srubami laczacymi orczyk z zebatka. Sprawdz zazebienie i luz
   na stole. Podkladki pod uszami serwa dobierz po fizycznej przymiarce.
   Skok serwa: **90 stopni (40 mm)** lub **101,25 stopnia (80 mm)**.
6. Pokrywe przykrec 4 srubami M2,5 (nominalnie 12 mm), po sprawdzeniu
   glebokosci pilotow. Wentylator i baze M1 mocuj 4 srubami M3 do krotkich
   metalowych wkladek w pokrywie. Nominalny otwor na wkladke 4,4 mm x
   4,2 mm; dopasuj do wkladki i pilnuj, by nie weszla pod pokrywe.
   Rozstaw wentylatora: 32 / 71,5 mm. Uwzglednij grubosc wentylatora,
   baze, podkladki i ok. 3 mm wejscia w wkladke; konce nie moga dotknac
   wirnika ani mechanizmu. Zaloz oslone po stronie dostepnej do wirnika.
7. Odlacz orczyk na czas sprawdzania polozenia rozruchowego i zakresu
   impulsow w coroNET. Po zalozeniu zaczynaj od malych ruchow i
   stopniowo ustaw konce. Napraw opor, zamiast zwiekszac moment serwa.

## Moduly M1

Wymiary interfejsu: cztery otwory M4 na kwadracie 110 x 110 mm,
nominalny przelot 76 mm. Uzyj elementow 04–08 z zestawu
`CHITU_MODULOWY_M1`: sama kaseta, sam krociec ID 80/100 lub kaseta
i krociec w szeregu. Uszczelnij polaczenia i podeprzyj filtr/rure osobno.
Nie montuj przewodu ani ciezkiego filtra na samej tkaninie.

## Wynik i ograniczenia

Sprawdzono pole przekroju w 101 pozycjach, nominalne luzy napedu w 81
pozycjach i kolizje bryl tacy/pokrywy z mechanizmem w 21 pozycjach
na rozmiar. Raporty: `RUCH.json` i `WALIDACJA_ZLOZENIA.json`.
`PODGLAD_N1.scad` pokazuje ruch STL; wentylator, serwo i tkanina sa
uproszczone. Nie drukuj widoku zlozenia.

Brak testu fizycznego: dopasowanie MG90S, tolerancje druku, wytrzymalosc
zacisku, ruch przy goracej tkaninie, przeplyw i szczelnosc pozostaja do
sprawdzenia. Pierwsza proba z odpietym napedem. Iris nie jest zaworem
szczelnym ani certyfikowanym systemem neutralizacji oparow.
