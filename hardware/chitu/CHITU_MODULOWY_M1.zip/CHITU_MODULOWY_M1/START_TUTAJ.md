# Chitu M1: filtr i wyciąg modułowy

Paczka dodatków do istniejących prototypów, nie zamiennik kompletnych
zespołów irisa ani klapy. Nie nadpisuje oryginalnych STL.

## Wybierz konfigurację

Przepływ w kierunku od Chitu na zewnątrz:

| Konfiguracja | Elementy M1 za zespołem wentylacji |
| --- | --- |
| Sam filtr | Baza + korpus kasety + pokrywa serwisowa + odpowiedni wkład |
| Sama rura | Baza + króciec ID 80 lub ID 100 mm + przewód z własnym podparciem |
| Filtr i rura | Baza + kaseta z pokrywą i wkładem + króciec ID 80 lub ID 100 mm |

Baza, obie strony kasety i króćce używają interfejsu: powierzchnia
126 × 126 mm, otwory przelotowe Ø4,4 mm na kwadracie 110 × 110 mm,
nominalny przelot Ø76 mm. Baza Iris 80 ma większy obrys 140 mm, ale
ten sam wzór otworów M4. Na jedno połączenie: cztery śruby M4 × 14–16,
podkładki i nakrętki, dobierane po uwzględnieniu uszczelki.
Uszczelnienie: cienki ciągły pierścień lub uszczelka dopasowana do obu
płaskich powierzchni; nie zasłaniać otworu. Przymierz najpierw część 09.
Montuj odcinkami: połącz bazę z kasetą przed dokręceniem króćca, żeby
zachować dostęp do nakrętek. Śruby M4 nie mogą sięgać do wirnika.

## Dobierz bazę

- **01: Iris 40 R2 i P1 40, rozstaw NF-A4x20 32 mm.** W Iris R2 obróć
  **cały moduł wentylacji z kołnierzem** względem tkaniny, nie samą
  klapę: gładka strona kołnierza do tkaniny, prowadnica irisa i korpus po
  zewnętrznej stronie, tylna ramka od środka. Załóż śruby pokrywy zanim
  przyłożysz kołnierz do tkaniny. Kierunek wentylatora ustaw od komory na
  zewnątrz. Zweryfikuj dostęp do śrub i kabel MG90S przed zaciśnięciem.
  To nowa konfiguracja montażu R2, nie potwierdzona na rzeczywistej pokrywie.
  W P1 40 moduł jest już na zewnątrz. Adapter w obu wersjach zakłada
  się na wylot wentylatora. Dłuższe śruby M3 przechodzą przez dno adaptera
  (4 mm) i wentylator. W R2 zachowaj dotychczasową głębokość wejścia
  w metalową wkładkę; w P1 sprawdź podkładki i wystawanie nakrętki.
- **02: Iris 80 R3, rozstaw obudowy 129 mm.** Płyta leży na zewnętrznej
  pokrywie irisa, za wentylatorem i przesłoną. Wewnętrznej kolejności
  wentylatora i irisa nie zmieniano. Użyj dłuższych śrub M2,5, o około
  4 mm względem oryginału; sprawdź, czy wkręt nie dobija do dna pilota
  i czy powtarzalnie chwyta gwint. Montuj tę bazę przed kasetą.
- **03: P1 80, rozstaw NF-A8 71,5 mm.** Płyta na wylocie wentylatora.
  Utrzymaj fabryczne poduszki. Dodaj grubość płyty 4 mm do stosu śrub
  M3 i sprawdź ich końce przed włączeniem wentylatora.

Baza dodaje **35,8 mm** po stronie wylotu dla 40 mm lub **4 mm** dla
80 mm. Kaseta dodaje **38 mm**, króciec **33,9 mm**. Dla P1 80
z obydwoma modułami jest to około **191 mm od tkaniny** bez rury i uszczelek.
Nie podwieszaj takiego zestawu ani przewodu na samej tkaninie.

## Kaseta i przewód

- 04 to korpus, 05 to boczna pokrywa, 06 to **sprawdzian gabarytu
  95 × 95 × 14 mm, nie filtr**. Wsad dobierz przed drukiem docelowej
  kasety. Zostaw miejsce na uszczelnienie wokół kompletnego wkładu:
  bez uszczelnienia powietrze może płynąć obok niego. Zastosuj osobną
  płaską uszczelkę także pod pokrywą serwisową. Cztery otwory M3 pokrywy
  są przelotowe; potrzebne są nakrętki. Przed drukiem obejrzyj podpory
  korpusu w slicerze, szczególnie od strony prowadnic. Sensowna orientacja
  próbna: okno serwisowe do góry, podpory poza drogą wsuwania wkładu.
- 07 i 08 są pod **elastyczny przewód o nominalnym ID 80/100 mm**.
  Zmierz realną średnicę przed drukiem. Rant jest większy od średnicy
  nominalnej, więc nie zakładaj kompatybilności ze sztywną rurą bez mufy.
  Zastosuj opaskę i osobny wspornik przewodu lub filtra.
- Sama kaseta wymaga osłony tam, gdzie od wylotu da się dosięgnąć wirnika.
  Nie testuj z dostępnym wirnikiem. Jeśli docelowy układ ma ograniczać
  ekspozycję na emisje, przed użyciem sprawdź szczelność i rzeczywisty
  przepływ z wkładem i całą trasą rury. Nie wystarczy, że wentylator się kręci.
  Nie ma pomiaru przepływu, filtracji ani skuteczności odprowadzania oparów.

## Weryfikacja

9 poprawnych pojedynczych brył STL; 11 par połączeń sprawdzonych w CAD oraz
56 pozycji wsuwania sprawdzianu wkładu. Szczegóły i sumy SHA-256 w
`WALIDACJA.json`. Bez testu fizycznego na Chitu. Podgląd konfiguracji
pokazuje wyłącznie połączenia modułowe, bez wentylatora i Chitu.
