// Assembly preview only. Source STL units: mm.
// Set angle = 90 to show the fully open butterfly. Hide the top for inspection.
angle = 0;
show_top = true;
h = 21;
r = 19;
offset = 0;
color("SlateGray") translate([0,0,-h-4]) import("STL/01_korpus_dolny_z_kolnierzem_1szt.stl");
if (show_top) color("LightSteelBlue", .5) translate([0,0,h+4]) rotate([180,0,0])
    import("STL/02_korpus_gorny_z_mocowaniem_wentylatora_1szt.stl");
color("Orange") translate([offset,0,0]) rotate([angle,0,0]) translate([0,0,-4.45])
    import("STL/03_klapa_z_osia_1szt.stl");
color("Gold") translate([offset,0,0]) rotate([angle,0,0]) translate([r+8.35,0,0])
    rotate([0,-90,0]) translate([0,0,-9.1])
    import("STL/04_sprzeglo_D_do_orczyka_1szt.stl");
color("Gainsboro") translate([0,0,-h-10.2]) import("STL/05_ramka_wewnetrzna_1szt.stl");
for (x=[-45,45], y=[-45,45]) color("Silver") translate([x,y,-h-5.2])
    import("STL/06_ogranicznik_1p2mm_4szt.stl");
