// Left: filter alone. Center: duct alone. Right: filter plus duct.
module base() {color("SlateGray") import("STL/03_baza_NF_A8_klapa_P1_80.stl");}
module filter() {
    color("SteelBlue") import("STL/04_korpus_kasety_95mm.stl");
    color("LightSteelBlue") translate([0,-61,0]) rotate([-90,0,0])
        import("STL/05_pokrywa_serwisowa_kasety.stl");
}
module tube() {color("Orange") import("STL/07_krociec_rura_ID80.stl");}
translate([-143,0,0]) {base(); translate([0,0,4]) filter();}
{base(); translate([0,0,4]) tube();}
translate([143,0,0]) {base(); translate([0,0,4]) filter(); translate([0,0,42]) tube();}
