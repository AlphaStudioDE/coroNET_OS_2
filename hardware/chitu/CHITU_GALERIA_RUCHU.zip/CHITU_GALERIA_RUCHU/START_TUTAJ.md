# Galeria wentylacji Chitu

Każdy zestaw ma trzy rendery z tkaniną (zewnątrz, strona głowicy, profil)
i zapętloną animację od zamknięcia do otwarcia i z powrotem.
W animacji usunięto lub ukryto elementy zasłaniające ruch, zależnie od modelu.
Rendery używają STL części; tkanina, wentylatory, serwa i elementy złączne
są uproszczonymi modelami referencyjnymi, nie skanem rzeczywistej drukarki.
Widoki mają różne powiększenia i nie są wymiarowymi rysunkami technicznymi.

| Konstrukcja i montaż | Animacja | Zewnątrz | Przy głowicy | Profil |
| --- | --- | --- | --- | --- |
| Starszy Iris R2 40, oryginalnie do środka | [GIF](R2_IRIS40_ORYGINAL/04_RUCH.gif) | [PNG](R2_IRIS40_ORYGINAL/01_ZEWNATRZ.png) | [PNG](R2_IRIS40_ORYGINAL/02_OD_GLOWICY.png) | [PNG](R2_IRIS40_ORYGINAL/03_PROFIL.png) |
| Starszy Iris R2 40, odwrócony na zewnątrz | [GIF](R2_IRIS40_ZEWNETRZNY/04_RUCH.gif) | [PNG](R2_IRIS40_ZEWNETRZNY/01_ZEWNATRZ.png) | [PNG](R2_IRIS40_ZEWNETRZNY/02_OD_GLOWICY.png) | [PNG](R2_IRIS40_ZEWNETRZNY/03_PROFIL.png) |
| Starszy Iris R3 80 | [GIF](R3_IRIS80/04_RUCH.gif) | [PNG](R3_IRIS80/01_ZEWNATRZ.png) | [PNG](R3_IRIS80/02_OD_GLOWICY.png) | [PNG](R3_IRIS80/03_PROFIL.png) |
| Klapa motylkowa P1 40 | [GIF](P1_MOTYL40/04_RUCH.gif) | [PNG](P1_MOTYL40/01_ZEWNATRZ.png) | [PNG](P1_MOTYL40/02_OD_GLOWICY.png) | [PNG](P1_MOTYL40/03_PROFIL.png) |
| Klapa motylkowa P1 80 | [GIF](P1_MOTYL80/04_RUCH.gif) | [PNG](P1_MOTYL80/01_ZEWNATRZ.png) | [PNG](P1_MOTYL80/02_OD_GLOWICY.png) | [PNG](P1_MOTYL80/03_PROFIL.png) |
| Nowy Iris N1 40 z bazą M1 | [GIF](N1_IRIS40/04_RUCH.gif) | [PNG](N1_IRIS40/01_ZEWNATRZ.png) | [PNG](N1_IRIS40/02_OD_GLOWICY.png) | [PNG](N1_IRIS40/03_PROFIL.png) |
| Nowy Iris N1 80 z bazą M1 | [GIF](N1_IRIS80/04_RUCH.gif) | [PNG](N1_IRIS80/01_ZEWNATRZ.png) | [PNG](N1_IRIS80/02_OD_GLOWICY.png) | [PNG](N1_IRIS80/03_PROFIL.png) |

W profilach ciemny panel to tkanina. Góra obrazu to zewnętrzna strona
pokrywy, dół to wnętrze. W N1 poniżej tkaniny są tylko ramka i mocowania.
Na renderach N1 zielona płyta to interfejs M1, nie filtr.
W galerii pokazano aktualne wersje porównawcze, nie wcześniejsze,
zastąpione iteracje STL przed R2/R3.
